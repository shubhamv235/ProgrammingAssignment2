## Put comments here that give an overall description of what your
## functions do

## Write a short comment describing this function

             makeCacheMatrix <- function(x = matrix()) {
             inv <- NULL
  
             set <-function(y) 
    
             {
                x <<- y
                inv <<- NULL
             }
  
             get <-function() x
             setinverse <- function(inverse) inv <<- inverse
             getinverse <- function() inv
             list(set = set,
                  get = get,
                  setinverse = setinverse,
                  getinverse = getinverse)
  
      }


## Write a short comment describing this function
## The function given below calculates the the inverse of the matrix created by
## makeCacheMartix (written above). If the inverse has already been calculated 
## (and the matrix has not changed), it will retrieve the inverse from the cache.


            cacheSolve <- function(x, ...) 
         {
  
           ## Return a matrix that is the inverse of 'x'
  
            inv <- x$getinverse()
            if (!is.null(inv))
    
           {
             messaage("catched data is being get")
             return(inv)
           }
  
           mat <- x$get()
           inv <- solve(mat,...)
           x$setinverse(inv)
           inv
  
         }
